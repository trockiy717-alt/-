package com.example.elementswap;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record SwapPayload() implements CustomPayload {
    public static final Id<SwapPayload> ID =
            new Id<>(Identifier.of(ElementSwap.MOD_ID, "swap"));
    public static final PacketCodec<RegistryByteBuf, SwapPayload> CODEC =
            PacketCodec.unit(new SwapPayload());

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
