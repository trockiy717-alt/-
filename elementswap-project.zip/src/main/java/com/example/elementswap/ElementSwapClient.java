package com.example.elementswap;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;
import java.util.Random;

public class ElementSwapClient implements ClientModInitializer {

    // ===== Названия предметов (регистр не важен, ищется вхождение в название) =====
    private static final String[] STEAM = {"стихия пара"};
    private static final String[] SAMEHADA = {"самехада", "самихада", "samehada"};
    private static final String[] UZUMAKI = {"узумаки"};
    private static final String[] LAVA = {"стихия лав", "стихия лава"};
    private static final String[] LIGHTNING = {"стихия молни"};

    // ===== Время действия (тики, 20 тиков = 1 секунда) =====
    private static final int LAVA_TICKS = 5 * 20;
    private static final int LIGHTNING_TICKS = 4 * 20;

    // СКМ: сколько раз нажать и за какое время между нажатиями
    private static final int MIDDLE_CLICKS_NEEDED = 2;
    private static final int MIDDLE_CLICK_WINDOW = 20;

    // Задержки инвентаря в тиках (каждый раз случайно в диапазоне, чтобы выглядело как руками)
    private static final int OPEN_DELAY_MIN = 4, OPEN_DELAY_RANGE = 4;   // 4..7 тиков
    private static final int CLOSE_DELAY_MIN = 3, CLOSE_DELAY_RANGE = 4; // 3..6 тиков

    private static final Random RANDOM = new Random();

    // Клавиши, которые можно менять в Настройки -> Управление
    private static KeyBinding swapKey;   // Пар <-> Самехада (по умолчанию клавиша 3)
    private static KeyBinding lavaKey;   // необязательная замена СКМ (по умолчанию не назначена)

    private static long tickCounter = 0;
    private static boolean swapKeyWasDown = false;
    private static boolean middleWasDown = false;
    private static int middleClicks = 0;
    private static long lastMiddleTick = -1000;

    // ===== Задача "открыть инвентарь -> переложить -> закрыть" =====
    private interface Job {
        boolean run(MinecraftClient client, ClientPlayerEntity player);
    }

    private static int invStep = 0; // 0 нет, 1 ждём после открытия, 2 ждём перед закрытием
    private static long invStart = 0;
    private static long invSwapped = 0;
    private static int invOpenDelay = 4;
    private static int invCloseDelay = 3;
    private static boolean invSuccess = false;
    private static Job invJob = null;
    private static Runnable invAfter = null;

    // ===== Цепочка Узумаки -> Лава -> Молния -> Узумаки =====
    private static int chainStage = 0; // 0 нет, 1 лава, 2 молния
    private static int chainTimer = 0;
    private static int homeUzumaki, homeLava, homeLightning;

    @Override
    public void onInitializeClient() {
        swapKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.elementswap.swap", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_3, "category.elementswap.main"));
        lavaKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.elementswap.lava", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN, "category.elementswap.main"));

        ClientTickEvents.END_CLIENT_TICK.register(ElementSwapClient::tick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> reset());
    }

    private static void reset() {
        chainStage = 0;
        chainTimer = 0;
        middleClicks = 0;
        invStep = 0;
        invJob = null;
        invAfter = null;
    }

    private static void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null) {
            while (swapKey.wasPressed()) { }
            while (lavaKey.wasPressed()) { }
            reset();
            return;
        }

        tickCounter++;
        runInventoryTask(client, player);
        runChainTimer(client, player);

        // --- Клавиша обмена Пар <-> Самехада (опрос состояния, без конфликта с хотбаром) ---
        while (swapKey.wasPressed()) { }
        boolean swapDown = isBindingDown(client, swapKey);
        boolean swapPressed = swapDown && !swapKeyWasDown;
        swapKeyWasDown = swapDown;

        // --- СКМ (колёсико) ---
        boolean middleDown = GLFW.glfwGetMouseButton(client.getWindow().getHandle(),
                GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;
        boolean middlePressed = middleDown && !middleWasDown;
        middleWasDown = middleDown;
        while (lavaKey.wasPressed()) middlePressed = true;

        if (client.currentScreen == null && invStep == 0) {
            if (swapPressed) startSteamSamehadaSwap(client, player);
            if (middlePressed) onMiddle(client, player);
        }
    }

    // ============ Открыть инвентарь -> переложить -> закрыть ============

    private static boolean openAndSwap(MinecraftClient client, ClientPlayerEntity player,
                                       Job job, Runnable after) {
        if (invStep != 0) return false;
        invJob = job;
        invAfter = after;
        invSuccess = false;
        invOpenDelay = OPEN_DELAY_MIN + RANDOM.nextInt(OPEN_DELAY_RANGE);
        invCloseDelay = CLOSE_DELAY_MIN + RANDOM.nextInt(CLOSE_DELAY_RANGE);
        client.setScreen(new InventoryScreen(player));
        invStep = 1;
        invStart = tickCounter;
        return true;
    }

    private static void runInventoryTask(MinecraftClient client, ClientPlayerEntity player) {
        if (invStep == 0) return;

        if (invStep == 1) {
            if (tickCounter - invStart < invOpenDelay) return;
            if (!(client.currentScreen instanceof InventoryScreen)) {
                invStep = 0; // инвентарь закрыли раньше времени, отмена
                return;
            }
            invSuccess = invJob != null && invJob.run(client, player);
            invStep = 2;
            invSwapped = tickCounter;
        } else if (invStep == 2 && tickCounter - invSwapped >= invCloseDelay) {
            if (client.currentScreen instanceof InventoryScreen) {
                player.closeHandledScreen();
            }
            invStep = 0;
            Runnable after = invAfter;
            invJob = null;
            invAfter = null;
            if (invSuccess && after != null) after.run();
        }
    }

    // ============ Пар <-> Самехада ============

    private static void startSteamSamehadaSwap(MinecraftClient client, ClientPlayerEntity player) {
        PlayerInventory inv = player.getInventory();
        if (find(inv, STEAM, -1) == -1 || find(inv, SAMEHADA, -1) == -1) {
            return;
        }
        openAndSwap(client, player, (c, p) -> {
            PlayerInventory i = p.getInventory();
            int steam = find(i, STEAM, -1);
            int sam = find(i, SAMEHADA, -1);
            if (steam == -1 || sam == -1) return false;
            return swapSlots(c, p, steam, sam);
        }, null);
    }

    // ============ Узумаки -> Лава -> Молния -> Узумаки ============

    private static void onMiddle(MinecraftClient client, ClientPlayerEntity player) {
        PlayerInventory inv = player.getInventory();
        ItemStack inHand = inv.getStack(inv.selectedSlot);

        if (chainStage == 1) {
            if (matches(inHand, LAVA)) startLightning(client, player);
            return;
        }
        if (chainStage != 0) return;

        if (!matches(inHand, UZUMAKI)) {
            middleClicks = 0;
            return;
        }

        if (tickCounter - lastMiddleTick > MIDDLE_CLICK_WINDOW) {
            middleClicks = 0;
        }
        middleClicks++;
        lastMiddleTick = tickCounter;

        if (middleClicks >= MIDDLE_CLICKS_NEEDED) {
            middleClicks = 0;
            startLava(client, player);
        }
    }

    private static void startLava(MinecraftClient client, ClientPlayerEntity player) {
        PlayerInventory inv = player.getInventory();
        if (find(inv, LAVA, inv.selectedSlot) == -1) {
            return;
        }
        openAndSwap(client, player, (c, p) -> {
            PlayerInventory i = p.getInventory();
            int sel = i.selectedSlot;
            int lava = find(i, LAVA, sel);
            if (lava == -1 || !matches(i.getStack(sel), UZUMAKI)) return false;
            if (!swapSlots(c, p, sel, lava)) return false;
            homeUzumaki = sel;
            homeLava = lava;
            return true;
        }, () -> {
            MinecraftClient c = MinecraftClient.getInstance();
            chainStage = 1;
            chainTimer = LAVA_TICKS;
            virtualPress(c.options.swapHandsKey); // сразу F (способность лавы)
        });
    }

    private static void startLightning(MinecraftClient client, ClientPlayerEntity player) {
        PlayerInventory inv = player.getInventory();
        if (find(inv, LIGHTNING, -1) == -1) {
            return;
        }
        openAndSwap(client, player, (c, p) -> {
            PlayerInventory i = p.getInventory();
            int lavaPos = find(i, LAVA, -1);
            int lightning = find(i, LIGHTNING, -1);
            if (lavaPos == -1 || lightning == -1) return false;
            if (!swapSlots(c, p, lavaPos, lightning)) return false;
            homeLightning = lightning;
            return true;
        }, () -> {
            chainStage = 2;
            chainTimer = LIGHTNING_TICKS;
        });
    }

    private static void runChainTimer(MinecraftClient client, ClientPlayerEntity player) {
        if (chainStage == 0 || invStep != 0) return; // пока идёт перекладывание, время стоит
        if (chainTimer > 0) chainTimer--;
        if (chainTimer > 0) return;

        // Время вышло. Ждём, пока закроются другие окна, и возвращаем всё через инвентарь
        if (client.currentScreen != null) return;

        openAndSwap(client, player, (c, p) -> {
            place(c, p, UZUMAKI, homeUzumaki);
            place(c, p, LAVA, homeLava);
            if (chainStage == 2) {
                place(c, p, LIGHTNING, homeLightning);
            }
            return true;
        }, () -> chainStage = 0);
    }

    // Ставит предмет с таким названием в нужный слот (меняя местами с тем, что там лежит)
    private static void place(MinecraftClient client, ClientPlayerEntity player,
                              String[] names, int target) {
        int cur = find(player.getInventory(), names, -1);
        if (cur == -1) return;
        if (cur != target) swapSlots(client, player, cur, target);
    }

    // ===================== Общие функции =====================

    // Имитирует нажатие клавиши: игра обработает его в начале следующего тика
    private static void virtualPress(KeyBinding binding) {
        KeyBinding.onKeyPressed(KeyBindingHelper.getBoundKeyOf(binding));
    }

    private static boolean isBindingDown(MinecraftClient client, KeyBinding binding) {
        InputUtil.Key key = KeyBindingHelper.getBoundKeyOf(binding);
        long window = client.getWindow().getHandle();
        if (key.getCategory() == InputUtil.Type.MOUSE) {
            return GLFW.glfwGetMouseButton(window, key.getCode()) == GLFW.GLFW_PRESS;
        }
        if (key.getCategory() == InputUtil.Type.KEYSYM && key.getCode() != GLFW.GLFW_KEY_UNKNOWN) {
            return InputUtil.isKeyPressed(window, key.getCode());
        }
        return false;
    }

    // Меняет местами два слота инвентаря (индексы: 0-8 хотбар, 9-35 основной).
    // Возвращает false, если нужно, но курсор занят.
    private static boolean swapSlots(MinecraftClient client, ClientPlayerEntity player, int a, int b) {
        if (a == b) return true;
        if (a < 9) {
            click(client, player, toHandlerSlot(b), a, SlotActionType.SWAP);
        } else if (b < 9) {
            click(client, player, toHandlerSlot(a), b, SlotActionType.SWAP);
        } else {
            if (!player.playerScreenHandler.getCursorStack().isEmpty()) {
                return false;
            }
            click(client, player, toHandlerSlot(a), 0, SlotActionType.PICKUP);
            click(client, player, toHandlerSlot(b), 0, SlotActionType.PICKUP);
            click(client, player, toHandlerSlot(a), 0, SlotActionType.PICKUP);
        }
        return true;
    }

    private static void click(MinecraftClient client, ClientPlayerEntity player,
                              int slot, int button, SlotActionType type) {
        client.interactionManager.clickSlot(
                player.playerScreenHandler.syncId, slot, button, type, player);
    }

    private static int toHandlerSlot(int invIndex) {
        return invIndex < 9 ? invIndex + 36 : invIndex;
    }

    private static int find(PlayerInventory inv, String[] names, int skip) {
        for (int i = 0; i < 36; i++) {
            if (i != skip && matches(inv.getStack(i), names)) {
                return i;
            }
        }
        return -1;
    }

    private static boolean matches(ItemStack stack, String[] names) {
        if (stack.isEmpty()) return false;
        String n = stack.getName().getString().toLowerCase(Locale.ROOT);
        for (String s : names) {
            if (n.contains(s)) return true;
        }
        return false;
    }
}
