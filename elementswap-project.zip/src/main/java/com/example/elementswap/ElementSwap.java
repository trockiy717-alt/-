package com.example.elementswap;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class ElementSwap implements ModInitializer {
    public static final String MOD_ID = "elementswap";

    // Названия предметов (регистр не важен, ищется вхождение)
    private static final String[] STEAM = {"стихия пара"};
    private static final String[] SAMEHADA = {"самехада", "самихада", "samehada"};

    private static final int DURATION_TICKS = 13 * 20;

    private static final Map<UUID, Integer> timers = new HashMap<>();

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playC2S().register(SwapPayload.ID, SwapPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(SwapPayload.ID,
                (payload, context) -> trySwap(context.player()));

        ServerTickEvents.END_SERVER_TICK.register(this::tick);

        ServerPlayConnectionEvents.DISCONNECT.register(
                (handler, server) -> timers.remove(handler.getPlayer().getUuid()));
    }

    private void trySwap(ServerPlayerEntity player) {
        if (timers.containsKey(player.getUuid())) {
            return;
        }

        PlayerInventory inv = player.getInventory();
        int selected = inv.selectedSlot;

        if (!matches(inv.getStack(selected), STEAM)) {
            return;
        }

        int samehadaSlot = find(inv, SAMEHADA, selected);
        if (samehadaSlot == -1) {
            player.sendMessage(Text.literal("Самехада не найдена в инвентаре"), true);
            return;
        }

        swap(inv, selected, samehadaSlot);
        timers.put(player.getUuid(), DURATION_TICKS);
    }

    private void tick(MinecraftServer server) {
        Iterator<Map.Entry<UUID, Integer>> it = timers.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Integer> e = it.next();
            int left = e.getValue() - 1;
            if (left > 0) {
                e.setValue(left);
                continue;
            }
            it.remove();
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(e.getKey());
            if (player != null) {
                swapBack(player);
            }
        }
    }

    private void swapBack(ServerPlayerEntity player) {
        PlayerInventory inv = player.getInventory();
        int sam = find(inv, SAMEHADA, -1);
        int steam = find(inv, STEAM, -1);
        if (sam != -1 && steam != -1) {
            swap(inv, sam, steam);
        }
    }

    private static void swap(PlayerInventory inv, int a, int b) {
        ItemStack tmp = inv.getStack(a);
        inv.setStack(a, inv.getStack(b));
        inv.setStack(b, tmp);
    }

    private static int find(PlayerInventory inv, String[] names, int skip) {
        for (int i = 0; i < 36; i++) {
            if (i != skip && matches(inv.getStack(i), names)) {
                return i;
            }
        }
        return -1;
    }

    private static boolean matches(ItemStack stack, String[] names) {
        if (stack.isEmpty()) return false;
        String n = stack.getName().getString().toLowerCase(Locale.ROOT);
        for (String s : names) {
            if (n.contains(s)) return true;
        }
        return false;
    }
}
