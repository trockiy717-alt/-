КАК СОБРАТЬ МОД ЧЕРЕЗ GITHUB
1. Зарегистрируйся на github.com и нажми New repository (название любое, например elementswap).
2. На странице репозитория нажми "uploading an existing file" и перетащи ВСЁ содержимое
   этой папки (включая скрытую папку .github, src, build.gradle и т.д.). Нажми Commit changes.
3. Открой вкладку Actions. Сборка запустится сама, ждать 2-4 минуты.
4. Открой завершённый запуск, внизу в разделе Artifacts скачай elementswap-mod.
   Внутри zip лежит elementswap-1.0.0.jar.
5. Положи jar в папку mods вместе с Fabric API (Minecraft 1.21.1).

Кнопка по умолчанию G, меняется в Настройки -> Управление.

СБОРКА В INTELLIJ IDEA
1. File -> Open -> выбери папку проекта (где лежит build.gradle). Доверься проекту (Trust).
2. File -> Project Structure -> Project SDK: JDK 21 (если нет, IDEA предложит скачать).
   Settings -> Build Tools -> Gradle -> Gradle JVM: тоже 21.
3. Дождись, пока Gradle скачает всё (первый раз 5-15 минут, нужен интернет).
4. Справа вкладка Gradle -> elementswap -> Tasks -> build -> build (двойной клик).
   Или в терминале IDEA: gradlew build (Windows) / ./gradlew build (Linux, Mac).
5. Готовый мод: build/libs/elementswap-1.0.0.jar (НЕ файл с -sources в названии).
