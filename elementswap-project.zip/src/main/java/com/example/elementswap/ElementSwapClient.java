package com.example.elementswap;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

public class ElementSwapClient implements ClientModInitializer {

    // ===== Названия предметов (регистр не важен, ищется вхождение в название) =====
    private static final String[] STEAM = {"стихия пара"};
    private static final String[] SAMEHADA = {"самехада", "самихада", "samehada"};
    private static final String[] UZUMAKI = {"узумаки"};
    private static final String[] LAVA = {"стихия лав", "стихия лава"};
    private static final String[] LIGHTNING = {"стихия молни"};

    // ===== Время действия (тики, 20 тиков = 1 секунда) =====
    private static final int STEAM_TICKS = 13 * 20;
    private static final int LAVA_TICKS = 5 * 20;
    private static final int LIGHTNING_TICKS = 4 * 20;

    // Сколько раз нажать СКМ и за какое время между нажатиями
    private static final int MIDDLE_CLICKS_NEEDED = 3;
    private static final int MIDDLE_CLICK_WINDOW = 20;

    // Необязательные дополнительные клавиши (по умолчанию не назначены)
    private static KeyBinding steamKey;
    private static KeyBinding lavaKey;

    private static long tickCounter = 0;
    private static boolean fWasDown = false;
    private static boolean middleWasDown = false;
    private static int middleClicks = 0;
    private static long lastMiddleTick = -1000;

    // Пар -> Самехада
    private static int steamTimer = 0;

    // Узумаки -> Лава -> Молния -> Узумаки
    private static int chainStage = 0; // 0 нет, 1 лава, 2 молния
    private static int chainTimer = 0;
    private static int homeUzumaki, homeLava, homeLightning;

    @Override
    public void onInitializeClient() {
        steamKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.elementswap.steam", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN, "category.elementswap.main"));
        lavaKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.elementswap.lava", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN, "category.elementswap.main"));

        ClientTickEvents.END_CLIENT_TICK.register(ElementSwapClient::tick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> reset());
    }

    private static void reset() {
        steamTimer = 0;
        chainStage = 0;
        chainTimer = 0;
        middleClicks = 0;
    }

    private static void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null) {
            while (steamKey.wasPressed()) { }
            while (lavaKey.wasPressed()) { }
            reset();
            return;
        }

        tickCounter++;
        runSteamTimer(client, player);
        runChainTimer(client, player);

        // --- F (клавиша "Поменять предметы местами в руках"), нажатие не гасится ---
        boolean fDown = isBindingDown(client, client.options.swapHandsKey);
        boolean fPressed = fDown && !fWasDown;
        fWasDown = fDown;

        // --- СКМ (колёсико) ---
        boolean middleDown = GLFW.glfwGetMouseButton(client.getWindow().getHandle(),
                GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;
        boolean middlePressed = middleDown && !middleWasDown;
        middleWasDown = middleDown;

        boolean steamTrigger = false;
        while (steamKey.wasPressed()) steamTrigger = true;
        while (lavaKey.wasPressed()) middlePressed = true;

        if (client.currentScreen == null) {
            if (fPressed) steamTrigger = true;
            if (middlePressed) onMiddle(client, player);
        }

        if (steamTrigger) activateSteam(client, player);
    }

    // ===================== Пар -> Самехада =====================

    private static void activateSteam(MinecraftClient client, ClientPlayerEntity player) {
        if (steamTimer > 0) return;

        PlayerInventory inv = player.getInventory();
        int selected = inv.selectedSlot;
        if (!matches(inv.getStack(selected), STEAM)) return; // молча

        int sam = find(inv, SAMEHADA, selected);
        if (sam == -1) {
            player.sendMessage(Text.literal("Самехада не найдена в инвентаре"), true);
            return;
        }
        swapSlots(client, player, selected, sam);
        steamTimer = STEAM_TICKS;
        player.sendMessage(Text.literal("Самехада!"), true);
    }

    private static void runSteamTimer(MinecraftClient client, ClientPlayerEntity player) {
        if (steamTimer <= 0) return;
        steamTimer--;
        if (steamTimer > 0) return;

        PlayerInventory inv = player.getInventory();
        int steam = find(inv, STEAM, -1);
        int sam = find(inv, SAMEHADA, -1);
        if (steam == -1 || sam == -1) {
            player.sendMessage(Text.literal("Не удалось вернуть Стихию пара: предметы не найдены"), true);
            return;
        }
        if (!swapSlots(client, player, steam, sam)) {
            steamTimer = 1; // курсор занят, повторим в следующем тике
            return;
        }
        player.sendMessage(Text.literal("Стихия пара возвращена"), true);
    }

    // ============== Узумаки -> Лава -> Молния -> Узумаки ==============

    private static void onMiddle(MinecraftClient client, ClientPlayerEntity player) {
        PlayerInventory inv = player.getInventory();
        ItemStack inHand = inv.getStack(inv.selectedSlot);

        if (chainStage == 1) {
            // Лава в руке и ещё одно нажатие СКМ -> Молния
            if (matches(inHand, LAVA)) {
                startLightning(client, player);
            }
            return;
        }
        if (chainStage != 0) return;

        if (!matches(inHand, UZUMAKI)) {
            middleClicks = 0;
            return;
        }

        if (tickCounter - lastMiddleTick > MIDDLE_CLICK_WINDOW) {
            middleClicks = 0;
        }
        middleClicks++;
        lastMiddleTick = tickCounter;

        if (middleClicks >= MIDDLE_CLICKS_NEEDED) {
            middleClicks = 0;
            startLava(client, player);
        } else {
            player.sendMessage(Text.literal("СКМ " + middleClicks + "/" + MIDDLE_CLICKS_NEEDED), true);
        }
    }

    private static void startLava(MinecraftClient client, ClientPlayerEntity player) {
        PlayerInventory inv = player.getInventory();
        int selected = inv.selectedSlot;
        int lava = find(inv, LAVA, selected);
        if (lava == -1) {
            player.sendMessage(Text.literal("Стихия лавы не найдена в инвентаре"), true);
            return;
        }
        if (!swapSlots(client, player, selected, lava)) return;

        homeUzumaki = selected;
        homeLava = lava;
        chainStage = 1;
        chainTimer = LAVA_TICKS;
        player.sendMessage(Text.literal("Стихия лавы!"), true);
    }

    private static void startLightning(MinecraftClient client, ClientPlayerEntity player) {
        PlayerInventory inv = player.getInventory();
        int lavaPos = find(inv, LAVA, -1);
        int lightning = find(inv, LIGHTNING, -1);
        if (lavaPos == -1) return;
        if (lightning == -1) {
            player.sendMessage(Text.literal("Стихия молнии не найдена в инвентаре"), true);
            return;
        }
        if (!swapSlots(client, player, lavaPos, lightning)) return;

        homeLightning = lightning;
        chainStage = 2;
        chainTimer = LIGHTNING_TICKS;
        player.sendMessage(Text.literal("Стихия молнии!"), true);
    }

    private static void runChainTimer(MinecraftClient client, ClientPlayerEntity player) {
        if (chainStage == 0) return;
        if (chainTimer > 0) chainTimer--;
        if (chainTimer > 0) return;

        // Время вышло: возвращаем всё на исходные места
        if (!player.playerScreenHandler.getCursorStack().isEmpty()) {
            chainTimer = 1; // курсор занят, попробуем в следующем тике
            return;
        }
        boolean ok = place(client, player, UZUMAKI, homeUzumaki);
        ok &= place(client, player, LAVA, homeLava);
        if (chainStage == 2) {
            place(client, player, LIGHTNING, homeLightning);
        }
        chainStage = 0;
        player.sendMessage(Text.literal(ok ? "Узумаки возвращён"
                : "Не удалось вернуть предметы: не найдены в инвентаре"), true);
    }

    // Ставит предмет с таким названием в нужный слот (меняя местами с тем, что там лежит)
    private static boolean place(MinecraftClient client, ClientPlayerEntity player,
                                 String[] names, int target) {
        int cur = find(player.getInventory(), names, -1);
        if (cur == -1) return false;
        if (cur != target) swapSlots(client, player, cur, target);
        return true;
    }

    // ===================== Общие функции =====================

    private static boolean isBindingDown(MinecraftClient client, KeyBinding binding) {
        InputUtil.Key key = KeyBindingHelper.getBoundKeyOf(binding);
        long window = client.getWindow().getHandle();
        if (key.getCategory() == InputUtil.Type.MOUSE) {
            return GLFW.glfwGetMouseButton(window, key.getCode()) == GLFW.GLFW_PRESS;
        }
        if (key.getCategory() == InputUtil.Type.KEYSYM && key.getCode() != GLFW.GLFW_KEY_UNKNOWN) {
            return InputUtil.isKeyPressed(window, key.getCode());
        }
        return false;
    }

    // Меняет местами два слота инвентаря (индексы: 0-8 хотбар, 9-35 основной).
    // Возвращает false, если нужно, но курсор занят.
    private static boolean swapSlots(MinecraftClient client, ClientPlayerEntity player, int a, int b) {
        if (a == b) return true;
        if (a < 9) {
            click(client, player, toHandlerSlot(b), a, SlotActionType.SWAP);
        } else if (b < 9) {
            click(client, player, toHandlerSlot(a), b, SlotActionType.SWAP);
        } else {
            if (!player.playerScreenHandler.getCursorStack().isEmpty()) {
                return false;
            }
            click(client, player, toHandlerSlot(a), 0, SlotActionType.PICKUP);
            click(client, player, toHandlerSlot(b), 0, SlotActionType.PICKUP);
            click(client, player, toHandlerSlot(a), 0, SlotActionType.PICKUP);
        }
        return true;
    }

    private static void click(MinecraftClient client, ClientPlayerEntity player,
                              int slot, int button, SlotActionType type) {
        client.interactionManager.clickSlot(
                player.playerScreenHandler.syncId, slot, button, type, player);
    }

    private static int toHandlerSlot(int invIndex) {
        return invIndex < 9 ? invIndex + 36 : invIndex;
    }

    private static int find(PlayerInventory inv, String[] names, int skip) {
        for (int i = 0; i < 36; i++) {
            if (i != skip && matches(inv.getStack(i), names)) {
                return i;
            }
        }
        return -1;
    }

    private static boolean matches(ItemStack stack, String[] names) {
        if (stack.isEmpty()) return false;
        String n = stack.getName().getString().toLowerCase(Locale.ROOT);
        for (String s : names) {
            if (n.contains(s)) return true;
        }
        return false;
    }
}
