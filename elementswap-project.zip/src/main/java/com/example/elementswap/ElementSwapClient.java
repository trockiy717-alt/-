package com.example.elementswap;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

public class ElementSwapClient implements ClientModInitializer {
    // Названия предметов (регистр не важен, ищется вхождение в название)
    private static final String[] STEAM = {"стихия пара"};
    private static final String[] SAMEHADA = {"самехада", "самихада", "samehada"};

    private static final int DURATION_TICKS = 13 * 20;

    private static KeyBinding swapKey;
    private static int timer = 0;

    @Override
    public void onInitializeClient() {
        swapKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.elementswap.swap",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_V,
                "category.elementswap.main"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(ElementSwapClient::tick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> timer = 0);
    }

    private static void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null) {
            while (swapKey.wasPressed()) { }
            timer = 0;
            return;
        }

        if (timer > 0) {
            timer--;
            if (timer == 0) {
                int result = swapBack(client, player);
                if (result == 1) {
                    timer = 1; // курсор занят, пробуем ещё раз в следующем тике
                } else if (result == 2) {
                    player.sendMessage(Text.literal("Не удалось вернуть предметы: не найдены в инвентаре"), true);
                }
            }
        }

        while (swapKey.wasPressed()) {
            onKey(client, player);
        }
    }

    private static void onKey(MinecraftClient client, ClientPlayerEntity player) {
        if (timer > 0) {
            player.sendMessage(Text.literal("Эффект уже активен"), true);
            return;
        }

        PlayerInventory inv = player.getInventory();
        int selected = inv.selectedSlot;

        if (!matches(inv.getStack(selected), STEAM)) {
            player.sendMessage(Text.literal("В руке нет Стихии пара"), true);
            return;
        }

        int sam = find(inv, SAMEHADA, selected);
        if (sam == -1) {
            player.sendMessage(Text.literal("Самехада не найдена в инвентаре"), true);
            return;
        }

        // Меняем слот с Самехадой и выбранный слот хотбара местами
        click(client, player, toHandlerSlot(sam), selected, SlotActionType.SWAP);
        timer = DURATION_TICKS;
        player.sendMessage(Text.literal("Самехада!"), true);
    }

    // 0 = готово, 1 = повторить позже, 2 = ошибка
    private static int swapBack(MinecraftClient client, ClientPlayerEntity player) {
        PlayerInventory inv = player.getInventory();
        int sam = find(inv, SAMEHADA, -1);
        int steam = find(inv, STEAM, -1);
        if (sam == -1 || steam == -1) {
            return 2;
        }

        if (steam < 9) {
            click(client, player, toHandlerSlot(sam), steam, SlotActionType.SWAP);
        } else if (sam < 9) {
            click(client, player, toHandlerSlot(steam), sam, SlotActionType.SWAP);
        } else {
            if (!player.playerScreenHandler.getCursorStack().isEmpty()) {
                return 1;
            }
            click(client, player, toHandlerSlot(sam), 0, SlotActionType.PICKUP);
            click(client, player, toHandlerSlot(steam), 0, SlotActionType.PICKUP);
            click(client, player, toHandlerSlot(sam), 0, SlotActionType.PICKUP);
        }
        player.sendMessage(Text.literal("Стихия пара возвращена"), true);
        return 0;
    }

    private static void click(MinecraftClient client, ClientPlayerEntity player,
                              int slot, int button, SlotActionType type) {
        client.interactionManager.clickSlot(
                player.playerScreenHandler.syncId, slot, button, type, player);
    }

    // индекс в инвентаре (0-8 хотбар, 9-35 основной) -> номер слота в окне инвентаря
    private static int toHandlerSlot(int invIndex) {
        return invIndex < 9 ? invIndex + 36 : invIndex;
    }

    private static int find(PlayerInventory inv, String[] names, int skip) {
        for (int i = 0; i < 36; i++) {
            if (i != skip && matches(inv.getStack(i), names)) {
                return i;
            }
        }
        return -1;
    }

    private static boolean matches(ItemStack stack, String[] names) {
        if (stack.isEmpty()) return false;
        String n = stack.getName().getString().toLowerCase(Locale.ROOT);
        for (String s : names) {
            if (n.contains(s)) return true;
        }
        return false;
    }
}
