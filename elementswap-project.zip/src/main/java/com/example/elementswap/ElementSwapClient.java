package com.example.elementswap;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

public class ElementSwapClient implements ClientModInitializer {

    // ===== Названия предметов (регистр не важен, ищется вхождение в название) =====
    private static final String[] STEAM = {"стихия пара"};
    private static final String[] SAMEHADA = {"самехада", "самихада", "samehada"};
    private static final String[] UZUMAKI = {"узумаки"};
    private static final String[] LAVA = {"стихия лав", "стихия лава"};

    // Сколько тиков (20 тиков = 1 сек) можно ждать между нажатиями СКМ
    private static final int MIDDLE_CLICK_WINDOW = 20;
    private static final int MIDDLE_CLICKS_NEEDED = 3;

    private static final class Rule {
        final String[] held;   // предмет, который должен быть в руке
        final String[] other;  // предмет, который подставляется из инвентаря
        final int duration;
        final String msgOn, msgOff, msgNoHeld, msgNoOther;
        int timer = 0;

        Rule(String[] held, String[] other, int seconds,
             String msgOn, String msgOff, String msgNoHeld, String msgNoOther) {
            this.held = held;
            this.other = other;
            this.duration = seconds * 20;
            this.msgOn = msgOn;
            this.msgOff = msgOff;
            this.msgNoHeld = msgNoHeld;
            this.msgNoOther = msgNoOther;
        }
    }

    private static final Rule STEAM_RULE = new Rule(STEAM, SAMEHADA, 13,
            "Самехада!", "Стихия пара возвращена",
            "В руке нет Стихии пара", "Самехада не найдена в инвентаре");

    private static final Rule LAVA_RULE = new Rule(UZUMAKI, LAVA, 5,
            "Стихия лавы!", "Узумаки возвращён",
            "В руке нет Узумаки", "Стихия лавы не найдена в инвентаре");

    // Необязательные дополнительные клавиши (по умолчанию не назначены)
    private static KeyBinding steamKey;
    private static KeyBinding lavaKey;

    private static long tickCounter = 0;
    private static boolean fWasDown = false;
    private static boolean middleWasDown = false;
    private static int middleClicks = 0;
    private static long lastMiddleTick = -1000;

    @Override
    public void onInitializeClient() {
        steamKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.elementswap.steam", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN, "category.elementswap.main"));
        lavaKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.elementswap.lava", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN, "category.elementswap.main"));

        ClientTickEvents.END_CLIENT_TICK.register(ElementSwapClient::tick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> reset());
    }

    private static void reset() {
        STEAM_RULE.timer = 0;
        LAVA_RULE.timer = 0;
        middleClicks = 0;
    }

    private static void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null) {
            while (steamKey.wasPressed()) { }
            while (lavaKey.wasPressed()) { }
            reset();
            return;
        }

        tickCounter++;

        runTimer(client, player, STEAM_RULE);
        runTimer(client, player, LAVA_RULE);

        // --- Нажатие F (клавиша "Поменять предметы местами в руках") ---
        boolean fDown = isBindingDown(client, client.options.swapHandsKey);
        boolean fPressed = fDown && !fWasDown;
        fWasDown = fDown;

        // --- Нажатие СКМ (колёсико) ---
        boolean middleDown = GLFW.glfwGetMouseButton(client.getWindow().getHandle(),
                GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;
        boolean middlePressed = middleDown && !middleWasDown;
        middleWasDown = middleDown;

        boolean steamTrigger = false;
        boolean lavaTrigger = false;

        while (steamKey.wasPressed()) steamTrigger = true;
        while (lavaKey.wasPressed()) lavaTrigger = true;

        if (client.currentScreen == null) {
            if (fPressed) steamTrigger = true;

            if (middlePressed) {
                if (tickCounter - lastMiddleTick > MIDDLE_CLICK_WINDOW) {
                    middleClicks = 0;
                }
                middleClicks++;
                lastMiddleTick = tickCounter;
                if (middleClicks >= MIDDLE_CLICKS_NEEDED) {
                    middleClicks = 0;
                    lavaTrigger = true;
                }
            }
        }

        if (steamTrigger) activate(client, player, STEAM_RULE);
        if (lavaTrigger) activate(client, player, LAVA_RULE);
    }

    private static boolean isBindingDown(MinecraftClient client, KeyBinding binding) {
        InputUtil.Key key = KeyBindingHelper.getBoundKeyOf(binding);
        long window = client.getWindow().getHandle();
        if (key.getCategory() == InputUtil.Type.MOUSE) {
            return GLFW.glfwGetMouseButton(window, key.getCode()) == GLFW.GLFW_PRESS;
        }
        if (key.getCategory() == InputUtil.Type.KEYSYM && key.getCode() != GLFW.GLFW_KEY_UNKNOWN) {
            return InputUtil.isKeyPressed(window, key.getCode());
        }
        return false;
    }

    private static void runTimer(MinecraftClient client, ClientPlayerEntity player, Rule rule) {
        if (rule.timer <= 0) return;
        rule.timer--;
        if (rule.timer == 0) {
            int result = swapBack(client, player, rule);
            if (result == 1) {
                rule.timer = 1; // курсор занят, попробуем в следующем тике
            } else if (result == 2) {
                player.sendMessage(Text.literal("Не удалось вернуть предметы: не найдены в инвентаре"), true);
            }
        }
    }

    private static void activate(MinecraftClient client, ClientPlayerEntity player, Rule rule) {
        if (rule.timer > 0) {
            return; // эффект уже идёт
        }

        PlayerInventory inv = player.getInventory();
        int selected = inv.selectedSlot;

        if (!matches(inv.getStack(selected), rule.held)) {
            player.sendMessage(Text.literal(rule.msgNoHeld), true);
            return;
        }

        int other = find(inv, rule.other, selected);
        if (other == -1) {
            player.sendMessage(Text.literal(rule.msgNoOther), true);
            return;
        }

        click(client, player, toHandlerSlot(other), selected, SlotActionType.SWAP);
        rule.timer = rule.duration;
        player.sendMessage(Text.literal(rule.msgOn), true);
    }

    // 0 = готово, 1 = повторить позже, 2 = ошибка
    private static int swapBack(MinecraftClient client, ClientPlayerEntity player, Rule rule) {
        PlayerInventory inv = player.getInventory();
        int other = find(inv, rule.other, -1);
        int held = find(inv, rule.held, -1);
        if (other == -1 || held == -1) {
            return 2;
        }

        if (held < 9) {
            click(client, player, toHandlerSlot(other), held, SlotActionType.SWAP);
        } else if (other < 9) {
            click(client, player, toHandlerSlot(held), other, SlotActionType.SWAP);
        } else {
            if (!player.playerScreenHandler.getCursorStack().isEmpty()) {
                return 1;
            }
            click(client, player, toHandlerSlot(other), 0, SlotActionType.PICKUP);
            click(client, player, toHandlerSlot(held), 0, SlotActionType.PICKUP);
            click(client, player, toHandlerSlot(other), 0, SlotActionType.PICKUP);
        }
        player.sendMessage(Text.literal(rule.msgOff), true);
        return 0;
    }

    private static void click(MinecraftClient client, ClientPlayerEntity player,
                              int slot, int button, SlotActionType type) {
        client.interactionManager.clickSlot(
                player.playerScreenHandler.syncId, slot, button, type, player);
    }

    // индекс в инвентаре (0-8 хотбар, 9-35 основной) -> номер слота в окне инвентаря
    private static int toHandlerSlot(int invIndex) {
        return invIndex < 9 ? invIndex + 36 : invIndex;
    }

    private static int find(PlayerInventory inv, String[] names, int skip) {
        for (int i = 0; i < 36; i++) {
            if (i != skip && matches(inv.getStack(i), names)) {
                return i;
            }
        }
        return -1;
    }

    private static boolean matches(ItemStack stack, String[] names) {
        if (stack.isEmpty()) return false;
        String n = stack.getName().getString().toLowerCase(Locale.ROOT);
        for (String s : names) {
            if (n.contains(s)) return true;
        }
        return false;
    }
}
